Dashboard-projekt

Koder som vi har använt:
Scroll
https://github.com/peachananr/onepage-scroll
Kalender
http://unlockcampus.org/code/tutoring/duotone-calendar
Digital
https://codepen.io/afarrar/pen/JRaEjP
Slide-show
https://codepen.io/Danil89/pen/yoPBMP
Progress bar
https://www.youtube.com/watch?v=DKaOpZ_Nlrk


Språk som vi har använt
Html, Css, javascript, jQuery
